function showInformation(pBestFriend) {
  let message = window.alert(`Hello! My closest friend is: ${pBestFriend}`);
  return message;
}

function warning() {
  let message = window.alert("Sorry! The link will be activated very soon!");
  return message;
}
